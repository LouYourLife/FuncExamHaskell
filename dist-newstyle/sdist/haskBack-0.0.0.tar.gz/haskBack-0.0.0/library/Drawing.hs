module Drawing where

import Graphics.Gloss

main :: IO ()
main = display Fullscreen white (Circle 80)